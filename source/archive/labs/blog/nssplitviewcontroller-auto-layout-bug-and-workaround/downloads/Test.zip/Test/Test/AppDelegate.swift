//
//  NSSplitViewController constraints error edge case isolated/reproducible example.
//
//  Created by Aral Balkan on 30/03/2015.
//  Copyright (c) 2015 Ind.ie. Released under the MIT license.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate
{
}

