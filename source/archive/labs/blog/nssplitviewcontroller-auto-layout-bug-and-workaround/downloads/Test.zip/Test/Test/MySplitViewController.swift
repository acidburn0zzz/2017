//
//  NSSplitViewController constraints error edge case isolated/reproducible example.
//
//  Created by Aral Balkan on 30/03/2015.
//  Copyright (c) 2015 Ind.ie. Released under the MIT license.
//

import Cocoa

class MySplitViewController: NSSplitViewController
{
    
    @IBOutlet weak var secondSplitViewItem: NSSplitViewItem!

    override func viewDidLoad()
    {
        super.viewDidLoad()

        NSNotificationCenter.defaultCenter().addObserver(self, selector: "show:", name: "show", object: nil)
        
        //
        // Workaround, part 1: If you either turn off “Collapsed” in Interface Builder or if you uncomment the following
        // line of code to uncollapse the view now, you avoid the unsatisfiable constraint error.
        //
        
        // secondSplitViewItem.collapsed = false
        
        //
        // Workaround, part 2: Regardless of which method you use, you can then set the second split view item to 
        // collapsed in viewDidLoad and you will avoid the error when you press the button.
        //
        
        // secondSplitViewItem.collapsed = true
    }
    
    func show(notification:NSNotification)
    {
        //
        // Without the above workaround, when the split view item is uncollapsed here, it causes an unsatisfiable constraint error.
        //
        secondSplitViewItem.collapsed = false
    }
}

