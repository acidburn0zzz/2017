//
//  ViewController.swift
//  CartographySpike
//
//  Created by Aral Balkan on 06/04/2015.
//  Copyright (c) 2015 Ind.ie. Released under MIT.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet weak var background: NSImageView!
    @IBOutlet weak var longBox: NSImageView!
    @IBOutlet weak var shortBox: NSImageView!
    
    @IBOutlet weak var animateButton: NSButton!
    
    var backgroundConstraintGroup:ConstraintGroup?
    var contentsConstraintGroup:ConstraintGroup?
    
    override func viewWillAppear()
    {
        super.viewWillAppear()

        // Remove constraints added by Interface Builder while prototyping.
        self.view.removeConstraints(self.view.constraints)

        backgroundConstraintGroup = layout(background)
        {
            /* with */ background in
            
            // Make the background hug the edges of its superview exactly.
            background.top == background.superview!.top
            background.bottom == background.superview!.bottom
            background.left == background.superview!.left
            background.right == background.superview!.right
        }
        
        contentsConstraintGroup = layout(animateButton, longBox, shortBox)
        {
            /* with */ animateButton, longBox, shortBox in
        
            animateButton.center == animateButton.superview!.center
            
            longBox.width >= 274.0 ~ 1000                                       // Specify a minimum width for the long box and allow it to expand (all constraints at required—1,000—priority).
            longBox.height == 34.0 ~ 1000                                       // Specify a static height for the long box.
            longBox.left == longBox.superview!.left + 20.0 ~ 1000               // Inset the long box by 20 points from the left edge of its superview.
            longBox.bottom == longBox.superview!.bottom - 20.0 ~ 1000           // Inset the long box by 20 points from the bottom edge of its superview.
            
            shortBox.width == 78.0 ~ 1000                                       // Width of short box is static.
            shortBox.height == 34.0 ~ 1000                                      // Height of the short box is static.
            shortBox.left == longBox.right + 8.0 ~ 1000                         // Align the short box to the right of the long box using the default Cocoa distance.
            shortBox.right == shortBox.superview!.right - 20.0 ~ 1000           // Inset the short box by 20 points from the right edge of its superview.
            shortBox.bottom == shortBox.superview!.bottom - 20.0 ~ 1000         // Inset the short box by 20 points from the bottom edge of its superview.
            
        }
        
        // Debug: see the actualy NSLayoutConstraint instances that were created.
        // println(self.view.constraints)
    }
    
    
    @IBAction func animateButtonPressed(sender: NSButton)
    {
        // Animate the window’s frame.
        
        NSAnimationContext.runAnimationGroup(
            {
                /* with */ (context: NSAnimationContext!) -> Void in
                
                context.duration = 0.33
                context.allowsImplicitAnimation = true

                var windowFrame:NSRect = self.view.window!.frame
                windowFrame.size.width += 200.0
                windowFrame.size.height += 200.0
                windowFrame.origin.x -= 100.0
                windowFrame.origin.y -= 100.0
                
                self.view.window!.setFrame(windowFrame, display: true, animate: true)
                
            },
            completionHandler:
            {
                () -> Void in
                
                println("Animation complete. Window is now \(self.view.window!.frame.size.width) × \(self.view.window!.frame.size.height) points.")
            }
        )
        
    }
}

