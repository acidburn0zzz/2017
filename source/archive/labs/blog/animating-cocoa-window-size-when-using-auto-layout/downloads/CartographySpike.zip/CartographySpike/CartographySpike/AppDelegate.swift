//
//  AppDelegate.swift
//  CartographySpike
//
//  Created by Aral Balkan on 06/04/2015.
//  Copyright (c) 2015 Ind.ie. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

