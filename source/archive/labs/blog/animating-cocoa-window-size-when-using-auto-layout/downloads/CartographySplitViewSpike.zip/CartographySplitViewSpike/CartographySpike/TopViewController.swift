//
//  TopViewController.swift
//  CartographySpike
//
//  Created by Aral Balkan on 07/04/2015.
//  Copyright (c) 2015 Ind.ie. All rights reserved.
//

import Cocoa

class TopViewController: NSViewController {

    @IBOutlet weak var background: NSImageView!
    
    var backgroundConstraintGroup:ConstraintGroup?
    
    override func viewWillAppear()
    {
        // IB automatically generates three prototyping layout constraints
        // for this view:
        //
        // H:|-(0)-ImageView
        // V:|-(0)-ImageView
        // H:[ImageView(400) <-- This is the one that fucks things up when we resize the window.
        //
        // Let’s remove those first:
        self.view.removeConstraints(self.view.constraints)
        
        backgroundConstraintGroup = layout(view, background)
            {
                /* as */ myView, background in
                
                background.top == background.superview!.top
                background.bottom == background.superview!.bottom
                background.left == background.superview!.left
                background.right == background.superview!.right
                
                background.width >= 400.0
                background.height >= 150.0
        }
    }
    
}
