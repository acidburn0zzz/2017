////////////////////////////////////////////////////////////////////////////////
//
//  App Delegate
//
//  Demonstrates how to launch an external task (in this case a Node script.)
// 
//  We pass our process ID to the task (child process) so that it can monitor
//  our process and terminate gracefully if we go away.
//
//  The technique used in the Node script is compatible with the app sandbox.
//
//  Created by Aral Balkan on 12/04/2015.
//  Copyright (c) Aral Balkan (c) 2015 Ind.ie.
//  Released under the MIT license.
//
////////////////////////////////////////////////////////////////////////////////

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate
{
    var nodeTask:NSTask!

    // MARK: - Notification handlers.
    
    var pipeReadHandler:NotificationObserver!
    var pipeCloseHandler:NotificationObserver!
    
    // MARK: - Application lifecycle.
    
    func applicationDidFinishLaunching(aNotification: NSNotification)
    {
        //
        // Launch node task.
        //
        
        let mainBundle = NSBundle.mainBundle()
        
        // If any of these fail, we need a runtime error.
        let pathToNodeApp = mainBundle.pathForResource("boot", ofType: "js", inDirectory: "js")!
        let pathToNode = mainBundle.pathForResource("node", ofType: "")!
        let pathToAppFolder = pathToNodeApp.stringByDeletingLastPathComponent
        
        //
        // Create a pipe for reading the Node.js output
        //
        let pipe = NSPipe()
        
        //
        // Get our own process ID to pass to the child Node task. The Node task will
        // monitor our process and, if it notices that we’ve died, will kill itself
        // also. This is to avoid a dangling task messing things up the next time the
        // app is run.
        //
        // The dangling task scenario can occur if the app crashes
        // unexpectedly or if the app is killed by pressing the stop button in Xcode.
        // (I previously worked around this by creating a killnode script that looked
        // for and killed the dangling process but that’s not a great long-term
        // solution.)
        //
        
        let processIdentifier = NSProcessInfo.processInfo().processIdentifier
        
        println("Cocoa: My process identifier is \(processIdentifier).")
        
        //
        // Configure and launch the Node.js task, passing our process ID to the child process.
        //
        self.nodeTask = NSTask()
        self.nodeTask!.currentDirectoryPath = pathToAppFolder
        self.nodeTask!.launchPath = pathToNode
        self.nodeTask!.arguments = [pathToNodeApp, "\(processIdentifier)"]
        self.nodeTask!.standardOutput = NSPipe()
        self.nodeTask!.standardOutput.fileHandleForReading.readInBackgroundAndNotify()
        self.nodeTask!.launch()

        // Handle node pipe notifications
        //
        
        pipeReadHandler = handle(NSFileHandleReadCompletionNotification, from: self.nodeTask!.standardOutput.fileHandleForReading)
        {
            /* as */ notification in
            
            // There is console (standard out) output from the node task, display it.

            var data: NSData
            var text: NSString
            
            if let data = notification.userInfo![NSFileHandleNotificationDataItem] as? NSData
            {
                text = NSString(data: data, encoding: NSUTF8StringEncoding)!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
                
                if text == ""
                {
                    // Something went wrong on the server (we got a runtime error from Node).
                    // Gracefully shut down.
                    println("Cocoa: Node has exited. Exiting the Cocoa app also.")
                    self.cleanUp()
                    exit(EXIT_SUCCESS)
                }
                
                println("Node: \(text)")
            }

            // Ask the fileHandle to read in background again (this doesn’t happen automatically)
            self.nodeTask!.standardOutput.fileHandleForReading.readInBackgroundAndNotify()
        }

    
        pipeCloseHandler = handle(NSFileHandleReadToEndOfFileCompletionNotification, from: self.nodeTask!.standardOutput.fileHandleForReading)
        {
            /* as */ notification in
            
            println("Cocoa: Node pipe is closed.")
            println("\(notification)")
        }
        

    }
    

    func applicationWillTerminate(aNotification: NSNotification)
    {
        println("Cocoa: Application will terminate. Cleaning up.")
        cleanUp()
    }
    

    // MARK: - Helpers
    
    
    func cleanUp()
    {
        println("Cocoa: Cleaning up.")
        
        pipeReadHandler.remove()
        pipeCloseHandler.remove()
        
        self.nodeTask!.standardOutput.fileHandleForReading.closeFile()
        self.nodeTask!.terminate()
    }

}

