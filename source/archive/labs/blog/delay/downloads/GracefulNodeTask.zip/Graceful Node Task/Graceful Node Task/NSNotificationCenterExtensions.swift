//////////////////////////////////////////////////////////////////////////////////////////
//
//  NSNotificationCenterExtensions.swift
//
//  Provide a simple, human interface to NSNotificationCenter 
//  and functional shortcuts when using .defaultCenter()
//
//  Copyright © 2015 Aral Balkan. Released with ♥ by Ind.ie under the MIT License.
//
//////////////////////////////////////////////////////////////////////////////////////////

import Foundation

let 📡:NSNotificationCenter = NSNotificationCenter.defaultCenter()

extension NSNotificationCenter
{
    //
    // Syntactic sugar: let’s make the addObserver call literate.
    //
    
    //////////////////////////////////////////////////////////////////////////////////////
    //
    // Adding observers
    //
    //////////////////////////////////////////////////////////////////////////////////////
    
    //
    // Closure-based (preferred)
    // (See the public functions, below.)
    //
    
    //
    // Selector-based
    //
    
    public func when(youGet notificationName:String, call selector:Selector, on observer:AnyObject)
    {
        self.addObserver(observer, selector: selector, name: notificationName, object: nil)
    }

    
    public func when(youGet notificationName:String, from object:AnyObject?, call selector:Selector, on observer:AnyObject)
    {
        self.addObserver(observer, selector: selector, name: notificationName, object: object)
    }
    
    
    ////////////////////////////////////////////////////////////////////////////////////
    //
    // Removing observers
    //
    ////////////////////////////////////////////////////////////////////////////////////

    
    public func unsubscribe(#observer:AnyObject, fromNotificationsNamed name:String?)
    {
        self.removeObserver(observer, name: name, object: nil)
    }

    
    public func unsubscribe(#observer:AnyObject, fromNotificationsNamed name:String?, sentBy object:AnyObject?)
    {
        self.removeObserver(observer, name: name, object: object)
    }

    
    ////////////////////////////////////////////////////////////////////////////////////
    //
    // Sending notifications
    //
    ////////////////////////////////////////////////////////////////////////////////////

    
    public func send(notificationName:String, from object:AnyObject?, with userInfo:[NSObject : AnyObject]?)
    {
        self.postNotificationName(notificationName, object: object, userInfo: userInfo)
    }
    
    
    public func send(notificationName:String, from object:AnyObject?)
    {
        self.send(notificationName, from: object, with: nil)
    }
    
    
    public func send(notification:NSNotification)
    {
        self.postNotification(notification)
    }

}

//
// And hey, if we can remove two more characters and make it functional for 99% of use cases, why not?
//

//////////////////////////////////////////////////////////////////////////////////////////
//
// NSNotificationCenter.defaultCenter() functional shortcuts.
//
//////////////////////////////////////////////////////////////////////////////////////////

public typealias NotificationHandler = (NSNotification!) -> Void


public class NotificationObserver:NSObject
{
    var handler:NotificationHandler
    
    init(handler:NotificationHandler)
    {
        self.handler = handler
    }
    
    public func handlerProxy(notification:NSNotification!)
    {
        handler(notification)
    }
    
    public func remove()
    {
        📡.removeObserver(self)
    }
}


//////////////////////////////////////////////////////////////////////////////////////
//
// Adding observers
//
//////////////////////////////////////////////////////////////////////////////////////

//
// Closure-based (preferred)
//

public func handle(notificationName:String, with handler:NotificationHandler) -> NotificationObserver
{
    //
    // Instead of using the block-based methods of NSNotificationCenter, create an observer
    // object and return that for easy removing of the observer, etc.
    //
    let observer = NotificationObserver(handler: handler)
    📡.addObserver(observer, selector: "handlerProxy:", name: notificationName, object: nil)
    return observer
}


public func handle(notificationName:String, from object:AnyObject?, with handler:NotificationHandler) -> NotificationObserver
{
    let observer = NotificationObserver(handler: handler)
    📡.addObserver(observer, selector: "handlerProxy:", name: notificationName, object: object)
    return observer
}


//
// Selector-based
//


public func when(youGet notificationName:String, call selector:Selector, on observer:AnyObject)
{
    📡.addObserver(observer, selector: selector, name: notificationName, object: nil)
}


public func when(youGet notificationName:String, from object:AnyObject?, call selector:Selector, on observer:AnyObject)
{
    📡.addObserver(observer, selector: selector, name: notificationName, object: object)
}


////////////////////////////////////////////////////////////////////////////////////
//
// Removing observers
//
////////////////////////////////////////////////////////////////////////////////////


public func unsubscribe(#observer:AnyObject, fromNotificationsNamed name:String?)
{
    📡.removeObserver(observer, name: name, object: nil)
}


public func unsubscribe(#observer:AnyObject, fromNotificationsNamed name:String?, sentBy object:AnyObject?)
{
    📡.removeObserver(observer, name: name, object: object)
}


////////////////////////////////////////////////////////////////////////////////////
//
// Sending notifications
//
////////////////////////////////////////////////////////////////////////////////////


public func send(notificationName:String, from object:AnyObject?, with userInfo:[NSObject : AnyObject]?)
{
    println("About to post: \(notificationName) from \(object) with userInfo: \(userInfo)")
    📡.postNotificationName(notificationName, object: object, userInfo: userInfo)
}


public func send(notificationName:String, from object:AnyObject?)
{
    📡.send(notificationName, from: object, with: nil)
}


public func send(notification:NSNotification)
{
    📡.postNotification(notification)
}