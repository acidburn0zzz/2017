//
//  ViewController.swift
//  Graceful Node Task
//
//  Created by Aral Balkan on 12/04/2015.
//  Copyright (c) 2015 Ind.ie. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

