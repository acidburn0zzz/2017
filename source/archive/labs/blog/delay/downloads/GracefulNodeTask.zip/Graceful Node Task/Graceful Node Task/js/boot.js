//
// Coffeescript boot loader.
//

require('coffee-script/register');
require('./index.coffee');

